# Violin, Piano & Vocal Practice Skills Package

<!-- APAF Metadata -->
<!-- last_verified_date: 2026-11-15 -->
<!-- apaf_approved: true -->
<!-- apaf_version: 1.0 -->
<!-- apaf_org: APAF Bioinformatics -->

This package contains four AI assistant skills and one standalone Python helper script to translate PDF sheet music into verified **MusicXML (`.musicxml`)**, **GNU LilyPond (`.ly`)**, and **MIDI (`.mid`)** files, verify every bar with math/Lean 4, create slow practice editions (`75%`, `50%`, `33%`, `25%`, or custom BPM), and generate sing-along audio tracks.

## Included Files (Plain-Text Only)
1. `pdf-to-musescore/SKILL.md` — Main step-by-step workflow for converting PDFs to MuseScore (`.musicxml`) & GNU LilyPond (`.ly`) and running the double-check step.
2. `pdf-to-musescore/references/violin_and_piano_checklist.md` — Visual double-check guide for violin and piano notation plus MuseScore shortcuts.
3. `pdf-to-musescore/scripts/musescore_helper.py` — Standalone Python 3 standard-library script (`inspect`, `verify`, `slow` with `--lilypond`).
4. `slow-practice-musescore/SKILL.md` — Companion skill for graduated slow and ultra-slow practice files with 8th-note subdivision clicks and hands-separate piano parts.
5. `lean4-music-verification/SKILL.md` — Mathematical Lean 4 verification workflow for bar-beat conservation and cross-format equivalence.
6. `sing-from-sheet-music/SKILL.md` — Vocal Guide sing-along workflow (for learners without piano skills).
7. `SHA256SUMS.txt` — SHA-256 checksums for integrity verification.

## Safety & Privacy Guarantees
- **100% Plain Text**: Contains only human-readable Markdown (`.md`), checksums (`.txt`), and Python (`.py`) files. No compiled binaries or hidden files.
- **Zero Network Calls**: `musescore_helper.py` never connects to the internet or sends data anywhere.
- **Python Standard Library Only**: Core `verify`, `slow`, and `--lilypond` commands use only built-in Python 3 modules (`xml.etree.ElementTree`, `fractions`, `struct`, `pathlib`, `argparse`, `json`).

<!-- APAF Bioinformatics | README_FOR_TEACHER.md | Approved | 2026-11-15 -->
